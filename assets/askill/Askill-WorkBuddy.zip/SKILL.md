---
name: "vibe-astock"
description: "在 WorkBuddy 中安装、启动或修复短线王（Askill）本地 A 股短线复盘工作台。适用于首次部署、打开已有工作台做盘中跟踪或收盘复盘，以及恢复 AI 连接并验证对话。"
display_name: "短线王 · A 股短线复盘工作台"
display_name_en: "Askill · A-Share Market Review"
description_zh: "盘中看昨日涨停股能否延续强势，收盘对照连板梯队与当天记录的涨停原因，次日核对昨晚写下的判断。WorkBuddy 帮你在本机装好短线王，接入 AI，打开就能从最近一个交易日开始复盘。"
description_en: "Track yesterday’s limit-up stocks, review which themes and streaks held up at the close, and check your observations the next trading day. WorkBuddy sets up Askill on your computer and connects it to your account."
version: "1.0.1"
author: "Barryyangdong"
examples_zh: ["帮我安装短线王并接入 WorkBuddy，验证一次对话，带我打开最近一个交易日的收盘复盘。", "打开我已有的短线王，带我找到「次日验证」，我想核对昨天写下的观察条件。", "我的短线王能打开，但 AI 没回复。帮我检查连接，修好后在工作台验证一次。"]
examples_en: ["Install Askill, connect WorkBuddy, verify a reply, and open the latest trading day’s closing review.", "Open my existing Askill workspace and show me where to check the observations I recorded yesterday.", "Askill opens, but the AI does not reply. Check the connection, fix it, and verify a reply in the workbench."]
---
# 短线王 · A 股短线复盘工作台

收盘时觉得「今天的强势股比昨天更有持续性」，第二天还能说清，当时看到了什么、后来又发生了什么吗？短线王把昨日涨停股今天的表现、连板梯队和题材变化放在同一个工作台里。你可以顺着数据形成判断，在下一场竞价前留下观察条件，收盘后回来核对。

适合每天跟踪 A 股短线情绪、做题材复盘，或想用历史记录检验自己盘感的人。这个技能负责把工作台装到你的电脑上、在浏览器中打开，并接入你自己的 WorkBuddy。

## 用一个判断走完两天的复盘

**盘中，看看分歧发生在什么时候。** 同样是昨日涨停股午后转弱，开盘就低开和早盘冲高后回落，反映的是两种走势。在「盯盘 → 竞价与盘中」查看昨日涨停股的竞价表现，再沿已保存的盘中快照对照涨停家数、炸板家数和封板率。错过快照的时点会标明缺失。

**收盘，拆开「今天很强」这句话。** 打开「复盘」里的连板天梯，从昨天的首板往今天的二板看：有几只晋级，哪几只炸板？再看题材页，把涨停个股与当天记录的涨停原因对上。这样写下来的复盘，能具体到哪一层梯队、哪一个题材发生了变化。

**次日，给昨晚的判断对一次账。** 比如，收盘后在「次日验证」记下「下个交易日，首板晋级二板的比例会上升」。次日 09:15 起原条件锁定，盘中可看暂时读数，收盘后核对结果。积累一段时间，再看近 60 个交易日的验证记录，你能分清哪些判断有过反复验证，哪些只留下了一次鲜明印象。

![短线王收盘复盘实景，可查看市场情绪、涨跌分布和连板梯队](https://raw.githubusercontent.com/Barryyangdong/Askill/main/assets/askill/market-review.webp)

[查看更多实际界面，包括题材复盘与手机视图](https://github.com/Barryyangdong/Askill#界面预览)

## 想研究一种交易方法时

采集或导入你有权查看的比赛快照后，在「选手分析」选一个比赛日，对照当日可见的榜单和选手公开披露的交易，回看排名变化时他们实际做了什么。在「游资蒸馏」挑一个历史案例，先根据当时的材料写下自己的判断，再揭晓结果、对照反例。一个帮你核实发生过的操作，另一个让你检验自己是否真的理解了这种方法的适用条件。

## 从哪里开始

安装技能后，在 WorkBuddy 对话中说：

> 帮我安装并打开短线王，接入我的 WorkBuddy，验证一次对话，然后带我找到最近一个交易日的收盘复盘。

已有短线王时可以直接说「打开我现有的短线王，我想核对昨天的观察条件」。技能会复用已有项目和数据。首次部署需要联网获取项目和依赖；如果需要账号授权，由你在官方客户端完成。日常使用从浏览器中的工作台进入，行情与 AI 对话需要相应服务可用。

个人成交、持仓、成本和盈亏保存在本机，工作台不会自动把这些记录发给模型。你在对话中输入的内容，以及主动选择交给 AI 识别的截图或表格，会发送给所选模型。研究页面提供市场事实、历史案例与验证记录，不提供买卖建议。

## WorkBuddy 执行说明

收到安装、启动或修复请求时，先读取 @references/deployment.md，按用户机器的实际状态执行[标准部署流程](references/deployment.md)。从技能目录运行 `node scripts/configure-workbuddy.mjs --repo <项目绝对路径> --check`。启动当前项目后，用其实际本机页面地址执行 `--verify --ui-url <页面地址>`，在用户要使用的浏览器里完成接入。候选 CLI 的安装、本人授权、验证与保存均按参考文档执行。

交付时给出可打开的本机地址，分别说明真实连接、当前浏览器保存和工作台回复的验证结果。用户指定了复盘或验证页面时，按已部署版本的实际导航带到该入口。使用不含私人资料的短问题验证对话；遇到故障保留已有项目、数据和 AI 配置，按参考文档处理。

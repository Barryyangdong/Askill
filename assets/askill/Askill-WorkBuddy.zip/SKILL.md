---
name: "vibe-astock"
description: "在 WorkBuddy 中安装、启动或修复短线王（Askill）本地 A 股短线复盘工作台。适用于首次部署、打开已有工作台做盘中跟踪或收盘复盘，以及恢复 AI 连接并验证对话。"
display_name: "短线王 · A 股短线复盘工作台"
display_name_en: "Askill · A-Share Market Review"
description_zh: "4 个盯盘看板、5 个复盘看板，直接接入你已登录的 WorkBuddy，无需另填模型 API Key。盘中看竞价强弱和个股异动，收盘让 AI 从情绪、资金、题材、龙虎榜和龙头五个角度写复盘，点开依据核对数字。用「选手分析」比较同场领先组与落后组的持仓偏好，按交易日追踪一只股票谁新进、谁留守、谁退出。还可以拿游资历史案例做盲练，让 AI 梳理个股多空证据，用历史回测和次日验证检验判断。自己的成交和盈亏留在本机交易日志。"
description_en: "Four market-monitoring dashboards and five review dashboards connect to your signed-in WorkBuddy account without a separate model API key. Track auction strength and price moves, then ask AI to review sentiment, flows, themes, exchange trading disclosures, and leading stocks, with figures you can check. Player Analysis compares contest leaders and trailers and shows who added, kept, or exited a holding across comparable disclosures. Practice on historical trader cases, debate a stock with AI, and test ideas through backtests and next-day reviews. Your trade journal stays local."
version: "1.0.4"
author: "Barryyangdong"
examples_zh: ["用我的 WorkBuddy 账号接入短线王，无需另填模型 API Key。带我看最近一个交易日的 AI 复盘，并找到其中一条数字的依据。", "打开短线王的「选手分析」。用我有权查看的比赛快照比较领先组和落后组的持仓，再挑一只股票，看看哪些选手新持有、哪些已退出。", "打开我已有的短线王，带我找到个股研究的多空辩论入口。我想看看同一份资料分别支持哪些判断。"]
examples_en: ["Connect Askill using my WorkBuddy account without a separate model API key. Show me the latest available closing review and how to check the evidence behind one figure.", "Open Player Analysis. Use contest snapshots I have permission to view to compare the leading and trailing groups, then show me who added or exited a holding in one stock.", "Open my existing Askill workspace and show me where to start a bull-and-bear debate on an A-share stock using the same evidence."]
---
# 短线王 · A 股短线复盘工作台

短线王把 **4 个盯盘看板、5 个复盘看板和实盘比赛选手分析** 放在同一个本地工作台里。直接用你已登录且可正常对话的 **WorkBuddy 账号接入 AI，无需另填模型 API Key**。从竞价到收盘，你可以一路跟踪同一个题材，再请 AI 解释当天的变化，点开依据核对数字。

- **盯盘的 4 个看板**：市场动态、竞价与盘中、个股行情、市场资讯。在「竞价与盘中」沿已保存的 6 个时点回看，更容易分清强势股是开盘就弱，还是午后才回落。
- **复盘的 5 个看板**：盘面、题材、AI 解读、历史与统计、次日验证。其中「盘面」细分市场全景、短线情绪、涨停与接力、题材与资金、风险与验证、市场背景。「AI 解读」能从情绪、资金、题材、龙虎榜和龙头五个角度写收盘复盘，也能生成周报。

这个技能负责安装、打开工作台并验证 WorkBuddy 连接。进入后还可以围绕同一只股票开展 AI 多空辩论，把自己的思路写成条件做历史回测，或留到下一场收盘验证。

## 用一个判断走完两天的复盘

**盘中，看看分歧发生在什么时候。** 同样是昨日涨停股午后转弱，开盘就低开和早盘冲高后回落，反映的是两种走势。在「盯盘 → 竞价与盘中」查看昨日涨停股的竞价表现，再沿已保存的盘中快照对照涨停家数、炸板家数和封板率。错过快照的时点会标明缺失。

**收盘，拆开「今天很强」这句话。** 打开「复盘」里的连板天梯，从昨天的首板往今天的二板看：有几只晋级，哪几只炸板？再看题材页，把涨停个股与当天记录的涨停原因对上。这样写下来的复盘，能具体到哪一层梯队、哪一个题材发生了变化。

**次日，给昨晚的判断对一次账。** 比如，收盘后在「次日验证」记下「下个交易日，首板晋级二板的比例会上升」。次日 09:15 起原条件锁定，盘中可看暂时读数，收盘后核对结果。积累一段时间，再看近 60 个交易日的验证记录，你能分清哪些判断有过反复验证，哪些只留下了一次鲜明印象。

![短线王收盘复盘实景，可查看市场情绪、涨跌分布和连板梯队](https://raw.githubusercontent.com/Barryyangdong/Askill/main/assets/askill/market-review.webp)

[查看更多实际界面，包括题材复盘与手机视图](https://github.com/Barryyangdong/Askill#界面预览)

## 选手分析：从比赛排名看到具体持仓

想知道某只股票是全场都爱持有，还是更多出现在领先选手的报单里？采集或导入你有权查看的同场比赛快照，选定交易日，对照排名、收益以及领先组和落后组的持有率。点进这只股票，就能查看已披露的持有人名单。有连续可比报单时，还能逐日区分新增、继续和退出持有。明细被遮挡或当天缺报时，页面会标明可用样本，避免把缺数据误读成选手已经卖出。

## 用游资历史案例练习自己的判断

在「游资蒸馏」挑一个历史案例，先根据当时的材料写下自己的判断，再揭晓结果、对照反例，检查自己是否理解了这种方法的适用条件。

## 从哪里开始

安装技能后，在 WorkBuddy 对话中说：

> 帮我安装并打开短线王，接入我的 WorkBuddy，验证一次对话，然后带我找到最近一个交易日的收盘复盘。

已有短线王时可以直接说「打开我现有的短线王，我想核对昨天的观察条件」。技能会复用已有项目和数据。首次部署需要联网获取项目和依赖；如果需要账号授权，由你在官方客户端完成。日常使用从浏览器中的工作台进入，行情与 AI 对话需要相应服务可用。

个人成交、持仓、成本和盈亏保存在本机，工作台不会自动把这些记录发给模型。你在对话中输入的内容，以及主动选择交给 AI 识别的截图或表格，会发送给所选模型。研究页面提供市场事实、历史案例与验证记录，不提供买卖建议。

## WorkBuddy 执行说明

用户只说「启动应用」时，优先定位已有短线王实例或源码，核对页面和 API 健康后立即给出实际地址。即使 AI 尚未接通，也可浏览盯盘、复盘和交易日志。已有部署仅在用户要求使用或修复 AI 时进入下面的授权流程；首次完整安装按部署流程继续验证 AI，同时告知工作台何时已经可打开。

首次完整安装或用户要求接入、修复 AI 时，先读取 @references/deployment.md，按用户机器的实际状态执行[标准部署流程](references/deployment.md)。从技能目录运行 `node scripts/configure-workbuddy.mjs --repo <项目绝对路径> --check`。启动当前项目后，用其实际本机页面地址执行 `--verify --ui-url <页面地址>`，在用户要使用的浏览器里完成接入。候选 CLI 的安装、本人授权、验证与保存均按参考文档执行。

Windows 上固定使用通过项目运行时检查的 Node 可执行文件。若内置 CLI 真实对话失败，先验证可用的官方独立 CLI；只有选中的独立 CLI 确实需要本人授权时才引导登录。无法打开交互终端时，按参考文档生成配套的双击登录入口。

交付时给出可打开的本机地址，分别说明真实连接、当前浏览器保存和工作台回复的验证结果。用户指定了复盘或验证页面时，按已部署版本的实际导航带到该入口。使用不含私人资料的短问题验证对话；遇到故障保留已有项目、数据和 AI 配置，按参考文档处理。
